import os
import pandas as pd
from PyPDF2 import PdfMerger
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import threading

class PDFMergerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PDF Merger Tool")
        self.root.geometry("600x500")
        
        # Variables
        self.excel_file = ""
        self.output_folder = ""
        self.search_folders = []
        
        self.setup_ui()
    
    def setup_ui(self):
        # Title
        title = tk.Label(self.root, text="PDF Merger Tool", font=("Arial", 16, "bold"))
        title.pack(pady=10)
        
        # Instructions
        instructions = tk.Label(self.root, 
                              text="This tool will merge PDFs based on part numbers in your Excel file",
                              font=("Arial", 10))
        instructions.pack(pady=5)
        
        # Excel file selection
        excel_frame = tk.Frame(self.root)
        excel_frame.pack(pady=10, padx=20, fill="x")
        
        tk.Label(excel_frame, text="1. Select Excel file with part numbers:").pack(anchor="w")
        excel_button_frame = tk.Frame(excel_frame)
        excel_button_frame.pack(fill="x", pady=5)
        
        tk.Button(excel_button_frame, text="Browse Excel File", 
                 command=self.select_excel_file).pack(side="left")
        self.excel_label = tk.Label(excel_button_frame, text="No file selected", fg="gray")
        self.excel_label.pack(side="left", padx=10)
        
        # Column selection
        self.column_frame = tk.Frame(self.root)
        self.column_frame.pack(pady=10, padx=20, fill="x")
        
        tk.Label(self.column_frame, text="2. Select column with part numbers:").pack(anchor="w")
        self.column_var = tk.StringVar()
        self.column_dropdown = ttk.Combobox(self.column_frame, textvariable=self.column_var, 
                                          state="readonly", width=30)
        self.column_dropdown.pack(pady=5, anchor="w")
        
        # Search folders
        folder_frame = tk.Frame(self.root)
        folder_frame.pack(pady=10, padx=20, fill="x")
        
        tk.Label(folder_frame, text="3. Add folders to search for PDFs:").pack(anchor="w")
        folder_button_frame = tk.Frame(folder_frame)
        folder_button_frame.pack(fill="x", pady=5)
        
        tk.Button(folder_button_frame, text="Add Folder", 
                 command=self.add_search_folder).pack(side="left")
        tk.Button(folder_button_frame, text="Add Entire Drive", 
                 command=self.add_entire_drive).pack(side="left", padx=5)
        
        self.folder_listbox = tk.Listbox(folder_frame, height=4)
        self.folder_listbox.pack(fill="x", pady=5)
        
        # Output folder
        output_frame = tk.Frame(self.root)
        output_frame.pack(pady=10, padx=20, fill="x")
        
        tk.Label(output_frame, text="4. Select output folder:").pack(anchor="w")
        output_button_frame = tk.Frame(output_frame)
        output_button_frame.pack(fill="x", pady=5)
        
        tk.Button(output_button_frame, text="Browse Output Folder", 
                 command=self.select_output_folder).pack(side="left")
        self.output_label = tk.Label(output_button_frame, text="No folder selected", fg="gray")
        self.output_label.pack(side="left", padx=10)
        
        # Progress bar
        self.progress_frame = tk.Frame(self.root)
        self.progress_frame.pack(pady=10, padx=20, fill="x")
        
        self.progress_label = tk.Label(self.progress_frame, text="")
        self.progress_label.pack()
        
        self.progress_bar = ttk.Progressbar(self.progress_frame, mode='indeterminate')
        self.progress_bar.pack(fill="x", pady=5)
        
        # Start button
        self.start_button = tk.Button(self.root, text="Start Merging PDFs", 
                                    command=self.start_merging, bg="green", fg="white",
                                    font=("Arial", 12, "bold"))
        self.start_button.pack(pady=20)
        
        # Status text
        self.status_text = tk.Text(self.root, height=8, width=70)
        self.status_text.pack(pady=10, padx=20, fill="both", expand=True)
        
    def select_excel_file(self):
        file_path = filedialog.askopenfilename(
            title="Select Excel File",
            filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")]
        )
        if file_path:
            self.excel_file = file_path
            self.excel_label.config(text=os.path.basename(file_path), fg="black")
            self.load_excel_columns()
    
    def load_excel_columns(self):
        try:
            df = pd.read_excel(self.excel_file)
            columns = list(df.columns)
            self.column_dropdown['values'] = columns
            
            # Automatically select "Part Number" column if it exists
            if "Part Number" in columns:
                self.column_dropdown.set("Part Number")
                self.log_message("Automatically selected 'Part Number' column")
            elif columns:
                self.column_dropdown.set(columns[0])
        except Exception as e:
            messagebox.showerror("Error", f"Could not read Excel file: {str(e)}")
    
    def add_search_folder(self):
        folder_path = filedialog.askdirectory(title="Select Folder to Search")
        if folder_path:
            self.search_folders.append(folder_path)
            self.folder_listbox.insert(tk.END, folder_path)
    
    def add_entire_drive(self):
        drives = [f"{chr(i)}:\\" for i in range(65, 91) if os.path.exists(f"{chr(i)}:\\")]
        if drives:
            from tkinter import simpledialog
            drive = simpledialog.askstring("Select Drive", 
                                         f"Available drives: {', '.join(drives)}\nEnter drive letter (e.g., C):")
            if drive and len(drive) == 1:
                drive_path = f"{drive.upper()}:\\"
                if os.path.exists(drive_path):
                    self.search_folders.append(drive_path)
                    self.folder_listbox.insert(tk.END, drive_path)
                else:
                    messagebox.showerror("Error", f"Drive {drive_path} not found")
    
    def select_output_folder(self):
        folder_path = filedialog.askdirectory(title="Select Output Folder")
        if folder_path:
            self.output_folder = folder_path
            self.output_label.config(text=folder_path, fg="black")
    
    def log_message(self, message):
        self.status_text.insert(tk.END, message + "\n")
        self.status_text.see(tk.END)
        self.root.update()
    
    def find_pdf_files(self, part_numbers):
        """Search for PDF files matching part numbers"""
        found_files = {}
        total_parts = len(part_numbers)
        
        for i, part_number in enumerate(part_numbers):
            self.progress_label.config(text=f"Searching for {part_number} ({i+1}/{total_parts})")
            self.root.update()
            
            for search_folder in self.search_folders:
                for root, dirs, files in os.walk(search_folder):
                    for file in files:
                        if file.lower().endswith('.pdf'):
                            # Check if filename matches part number (with or without extension)
                            filename_without_ext = os.path.splitext(file)[0]
                            if (filename_without_ext == str(part_number) or 
                                file == str(part_number) or
                                filename_without_ext.lower() == str(part_number).lower()):
                                found_files[part_number] = os.path.join(root, file)
                                self.log_message(f"Found: {part_number} -> {file}")
                                break
                if part_number in found_files:
                    break
            
            if part_number not in found_files:
                self.log_message(f"WARNING: Could not find PDF for part number: {part_number}")
        
        return found_files
    
    def start_merging(self):
        # Validate inputs
        if not self.excel_file:
            messagebox.showerror("Error", "Please select an Excel file")
            return
        
        if not self.column_var.get():
            messagebox.showerror("Error", "Please select a column")
            return
        
        if not self.search_folders:
            messagebox.showerror("Error", "Please add at least one search folder")
            return
        
        if not self.output_folder:
            messagebox.showerror("Error", "Please select an output folder")
            return
        
        # Start merging in a separate thread
        self.start_button.config(state="disabled")
        self.progress_bar.start()
        
        thread = threading.Thread(target=self.merge_pdfs)
        thread.start()
    
    def merge_pdfs(self):
        try:
            # Read Excel file
            self.log_message("Reading Excel file...")
            df = pd.read_excel(self.excel_file)
            part_numbers = df[self.column_var.get()].dropna().tolist()
            
            self.log_message(f"Found {len(part_numbers)} part numbers in Excel")
            
            # Find PDF files
            self.log_message("Searching for PDF files...")
            found_files = self.find_pdf_files(part_numbers)
            
            # Merge PDFs
            self.progress_label.config(text="Merging PDFs...")
            merger = PdfMerger()
            merged_count = 0
            
            for part_number in part_numbers:
                if part_number in found_files:
                    try:
                        merger.append(found_files[part_number])
                        merged_count += 1
                        self.log_message(f"Added to merge: {part_number}")
                    except Exception as e:
                        self.log_message(f"ERROR: Could not merge {part_number}: {str(e)}")
            
            # Save merged PDF
            if merged_count > 0:
                # Use Excel filename for the output PDF
                excel_filename = os.path.splitext(os.path.basename(self.excel_file))[0]
                output_path = os.path.join(self.output_folder, f"{excel_filename}.pdf")
                merger.write(output_path)
                merger.close()
                
                self.log_message(f"\nSUCCESS! Merged {merged_count} PDFs")
                self.log_message(f"Output file: {output_path}")
                messagebox.showinfo("Success", f"Merged {merged_count} PDFs successfully!\nSaved to: {output_path}")
            else:
                self.log_message("ERROR: No PDFs were found to merge")
                messagebox.showerror("Error", "No PDFs were found to merge")
                
        except Exception as e:
            self.log_message(f"ERROR: {str(e)}")
            messagebox.showerror("Error", str(e))
        
        finally:
            self.progress_bar.stop()
            self.progress_label.config(text="")
            self.start_button.config(state="normal")

if __name__ == "__main__":
    root = tk.Tk()
    app = PDFMergerApp(root)
    root.mainloop()